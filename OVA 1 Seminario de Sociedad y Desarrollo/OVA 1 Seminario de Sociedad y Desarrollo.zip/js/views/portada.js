$( document ).ready(function() {
    setMigaja("Inicio","","");
    $( ".c-sidebar-nav > li").hide();
    $( ".c-sidebar-nav > .ov-inicio").show();
});