$(document).ready(function() {
	var img1 = `
				<img class="img_questionario" src="../img/img6/equation.png">
				`;
	$(".img_questionario1").html(img1);
});